<?php

namespace App\Http\Controllers;

use DB;
use Illuminate\Http\Request;

class Select2Controller extends Controller
{


    public function get_table_data(Request $request)
    {

        $data_where = array(
            '1' => array(), //general company Data
            '2' => array( 'item_type' => 'product'), //Item Type Product
            '3' => array( 'type' => 'income'), //Income Category
            '4' => array( 'type' => 'expense'), //Expense Category
            '5' => array('item_type' => 'service'), //Item Type Service
        );

        $table = $request->get('table');
        $value = $request->get('value');
        $display = $request->get('display');
        $display2 = $request->get('display2');
        $where = $request->get('where');
        $where2 = $request->get('where2');
        $q = $request->get('q');
        if ($where == 'ghl_api') {
            if ($table == 'contacts') {
                $dt = 'contacts?limit=100';
                if($q=='refresh'){
                    $q='';
                    session()->remove('ghlcontacts');
                }
                if(!empty($q) && strlen($q)<3){
                    return '';
                }else if(!empty($q) && strlen($q)>2){
                    $dt.='&query='.$q;
                }else{
                    if(session()->has('ghlcontacts')){
                        return session('ghlcontacts');
                    }
                }
                $resp = ghl_api_call($dt);
                if(!is_object($resp)){
                    $resp = json_decode($resp);
                }
                $options = '';
                if ($resp && $resp->contacts) {
                    $i = 0;
                    $contacts=[];
                    foreach ($resp->contacts as $res) {
                        $cnt = new \stdClass;
                        $cnt->id = $res->id;
                        $name = '';
                        if (!empty($res->contactName)) {
                            $name .= $res->contactName;
                        }
                        if (!empty($res->email)) {
                            if (!empty($name)) {
                                $name .= ' - ';
                            }
                            $name .= $res->email;
                        }
                        $cnt->text = $name;
                        if(!empty($name)){
                            $contacts[]=$cnt;
                        }
                    }
                    if(!session()->has('ghlcontacts')){
                        session(['ghlcontacts'=>$contacts]);
                    }
                    return $contacts;
                }
            }
            return;
        }
        $display_option = "$display as text";
        if ($display2 != '') {
            $display_option = "CONCAT($display,' - ',";
            if (strpos($display2, '|') !== false) {
                $dsp = explode('|', $display2);
                $op = 0;
                foreach ($dsp as $d) {
                    if ($op > 0) {
                        $display_option .= ",' - ',";
                    }
                    if (strpos($d, 'case') !== false) {
                        $d = str_replace('case=', '', $d);
                        $dx = explode('=', $d);
                        $case_id = " WHEN " . $dx[0] . " = '";
                        $display_option .= "CASE ";
                        $res = json_decode($dx[1]);
                        foreach ($res as $r) {
                            if ($r->id == 'def') {
                                $display_option .= " ELSE '" . $r->text . "' END";
                            } else {
                                $display_option .= " " . $case_id . $r->id . "' THEN  '" . $r->text . "'";
                            }
                        }
                    } else {
                        $display_option .= $d;
                    }
                    $op++;
                }
            } else {
                $display_option .= $display2;
            }
            $display_option .= ") AS text";
        }

        if ($where != '0') {
            $where2 = $data_where[$where];
            $where2['user_id']=login_id();
            $result = DB::table($table)
                ->select("$value as id", DB::raw($display_option))
                ->where($display, 'LIKE', "$q%")
                ->where($where2);
            if ($where2 != '') {
                $exp = explode('|', $where2);
                foreach ($exp as $p) {
                    $p1 = explode('=', $p);
                    $result->where($p1[0], $p1[1]);
                }

            }
            $result = $result->get();
        } else {
            $result = DB::table($table)
                ->select("$value as id", DB::raw($display_option))
                ->where($display, 'LIKE', "$q%")
                ->get();
        }

        return $result;
    }

}
