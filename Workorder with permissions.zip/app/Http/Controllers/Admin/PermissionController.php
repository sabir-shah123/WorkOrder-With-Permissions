<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\permission;
use App\Models\User;
use Illuminate\Http\Request;

class PermissionController extends Controller
{
    public function manage()
    {
        $company = auth()->user();
        
        $users = User::with('permissions')->where('role', company_role(true))->get();

        $first = $users->first();

        $permissions = objToArray($first->permissions->permission ?? null);
        $def_pers = objToArray(default_user_permissions());
        if (!$permissions) {
            $permissions =   $def_pers;
        }
        
        //diff
        $diff = array_diff_key($permissions, $def_pers);
        if(count($diff)>0){
            $permissions = array_merge($permissions, $diff);
         
        }
        
        return view('admin.permissions.manage', get_defined_vars());
    }

    public function save(Request $request)
    {
        $request->validate([
            'user_id' => 'required',
        ]);

        $user_id = $request->user_id;

        $perms = permission::where('user_id', $user_id)->first();
        if ($perms) {
            $perms->update([
                'permission' => $request->permissions
            ]);
        } else {
            permission::create([
                'user_id' => $user_id,
                'permission' => $request->permissions
            ]);
        }
        return response()->json([
            'status' => 'success',
            'message' => 'Permissions updated successfully'
        ]);
    }

    public function fetch(Request $request)
    {

        $perms = permission::where('user_id', $request->user_id)->first();
        if ($perms) {
            $permissions = json_decode($perms->permission);
        } else {
            $permissions =  default_user_permissions();
        }


        $html = view('admin.permissions.ajax', get_defined_vars())->render();

        return response()->json([
            'status' => 'success',
            'html' => $html
        ]);
    }
}
