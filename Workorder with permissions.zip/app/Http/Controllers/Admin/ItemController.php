<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Item;
use DataTables;
use Illuminate\Http\Request;

class ItemController extends Controller
{
    protected $route = 'item'; // route namespace
    protected $parent = 'Items'; //on list this will be title
    protected $model = \App\Models\Item::class;
    protected $titles = ['add' => 'Add Item', 'edit' => 'Edit Item'];
    public function __construct()
    {
        view()->share('route', $this->route);
        view()->share('parent', $this->parent);
    }
    function list(Request $req, $type = '') {
        $main_t = 'both';
        if (!$req->has('item_type') && $type!='') {
            $main_t1 = items_list_slug($type);
            $req->item_type = $main_t1;
            $main_t = $type;

        }
        if ($req->ajax()) {
            $query = $this->model::where(company_user_fk(), login_id())->orderBy('created_at', 'DESC');

            return DataTables::eloquent($query)
                ->filter(function ($query) use ($req) {
                    if ($req->has('item_type') && $req->item_type != "both") {
                        $type = items_list_slug($req->item_type);
                        $query->where('item_type', $type);
                    }
                })
                ->addIndexColumn()
                ->editColumn('id', function ($row) {
                    return $row->id;
                })
                ->editColumn('status', function ($row) {
                    return get_status($row->is_active);
                })
                ->editColumn('item_type', function ($row) {
                    return items_list(true)[$row->item_type];
                })
                ->addColumn('action', function ($row) {
                    $html = getAction();
                    $html .= change_status($row->id, $row->is_active, $this->route);
                    $html .= show_edit_del($row->id, $this->route, ['edit' => ['status' => true],'delete' => ['status' => true]]);
                    return $html;
                })

                ->rawColumns(['action','status' ,'type'])
                ->make(true);
        }

        return view('admin.item.list', get_defined_vars());
    }

    public function add($type = '')
    {
        $show_both=false;
        $type = items_list_slug($type);
        $title = $this->titles['add'];
        return view('admin.item.add', get_defined_vars());
    }

    public function edit($id = null)
    {
        $data = Item::findOrFail($id);
        $title =$data->item_title;
        $show_both=false;
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }


        return view('admin.item.edit', get_defined_vars());
    }

    public function save(Request $req, $id = null)
    {

        $req->validate([
            'item_title' => 'required',
            'item_price' => 'required',
            'item_type' => 'required',
            'item_unit_cost' => 'required',
        ]);

        if (is_null($id)) {
            $cat = new Item();
            $cat->{company_user_fk()} = login_id();
            // dd($cat->user_id);
            $msg = "Record Added Successfully!";
        } else {
            $cat = Item::findOrFail($id);
            if ($cat->{company_user_fk()} != login_id()) {
                return redirect()->back()->with('error', messages('not'));
            }
            $msg = "Record Edited Successfully!";
        }
        $cat->item_title = $req->item_title;
        $cat->item_price = $req->item_price;
        $cat->item_unit_cost = $req->item_unit_cost;
        $cat->item_type = $req->item_type;
        $cat->item_description = $req->item_description;

        $cat->save();
        if($req->has('save_add')){
            return  redirect()->route($this->route.'.list')->with('success', $msg);
         }
        return redirect()->back()->with('success', $msg);
    }

    public function delete($id = null)
    {
        $data = Item::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $data->delete();
        return redirect()->back()->with('success', 'Record Delete Successfully!');
    }

    public function status($id)
    {
        $Item = Item::find($id);
        if ($Item->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        if ($Item->is_active == 1) {
            $Item->is_active = 0;
        } elseif ($Item->is_active == 0) {
            $Item->is_active = 1;
        }

        $Item->save();
        return back()->with('success', 'Status Changed Successfully.');
    }
}
