<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\CustomField;
use Illuminate\Http\Request;
use DataTables;
class CustomFieldController extends Controller
{
    protected $route = 'custom-fields'; // route namespace
    protected $parent = 'Custom Fields'; //on list this will be title
    protected $model = \App\Models\CustomField::class;
    protected $titles = ['add' => 'Add Custom Field', 'edit' => 'Edit Custom Field'];
    public function __construct()
    {
        view()->share('route', $this->route);
        view()->share('parent', $this->parent);
    }
    function list(Request $req, $type = '',$folder='') {
        $show_all =true;
        $main_t = 'all';
       
        if (!$req->has('item_type') && $type != '') {
            $main_t1 = job_type_slug($type);
            $req->item_type = $main_t1;
            $main_t = $type;

        }
        if(!empty($folder)){
            $data = $this->model::findOrFail($folder);
            $title =$data->custom_field_name; 
        }
        if ($req->ajax()) {
            add_session('folder_id',$folder);
            $query = $this->model::where(company_user_fk(), login_id())->orderBy('position')->where('type','<>','Folder');
            if(!empty($folder)){
              
                $query->where('parent_id',$folder);
               
            }else{
                $query->whereNull('parent_id');
            }
            return DataTables::eloquent($query)
                ->filter(function ($query) use ($req) {
                    if ($req->has('item_type') && $req->item_type!="all") {
                        $type = job_type_slug($req->item_type);
                        $query->where('item_type', $type);
                    }
                })
                ->setRowId('id')
                ->addIndexColumn()
                ->editColumn('id', function ($row) {
                    return $row->id;
                })
                ->editColumn('position', function ($row) {
                    return showOrderIcon();
                })
                ->editColumn('item_type', function ($row) {
                    return job_type(true)[$row->item_type];
                })
                ->addColumn('action', function ($row) {
                    $html = getAction();
                    $title =job_type(true)[$row->item_type];
                    if($row->type=='Folder'){

                        $html .= dropdown_item([strtolower(str_replace(' ','',$title)),$row->id ], $this->route, 'list', 'Open Folder');
                    }
                    $html .= show_edit_del($row->id, $this->route, ['edit' => ['status' => true],'delete' => ['status' => true]]);
                    return $html;
                })

                ->rawColumns(['position','action', 'item_type'])
                ->make(true);
        }

        return view('admin.custom-fields.list', get_defined_vars());
    }

    function listfolders(Request $req, $type = '') {
        $show_all =true;
        $main_t = 'all';
       
        if (!$req->has('item_type') && $type != '') {
            $main_t = job_type_slug($type);
            $req->item_type = $main_t;
        }
        
        if ($req->ajax()) {
            
            $query = $this->model::where(company_user_fk(), login_id())->where('type','Folder')->orderBy('position');
            return DataTables::eloquent($query)
                ->filter(function ($query) use ($req) {
                    if ($req->has('item_type') && $req->item_type!="all") {
                        $type = job_type_slug($req->item_type);
                        $query->where('item_type', $type);
                    }
                })
                ->setRowId('id')
                ->addIndexColumn()
                ->editColumn('id', function ($row) {
                    return $row->id;
                })
                ->editColumn('position', function ($row) {
                    return showOrderIcon();
                })
                ->editColumn('custom_field_name', function ($row) {
                    $title =job_type(true)[$row->item_type];
                    return dropdown_item([strtolower(str_replace(' ','',$title)),$row->id ], $this->route, 'list', $row->custom_field_name);
                })
                ->editColumn('item_type', function ($row) {
                    return job_type(true)[$row->item_type];
                })
                ->addColumn('action', function ($row) {
                    $html = getAction();
                    $title =job_type(true)[$row->item_type];
                    if($row->type=='Folder'){

                        $html .= dropdown_item([strtolower(str_replace(' ','',$title)),$row->id ], $this->route, 'list', 'Open Folder');
                    }
                    $html .= show_edit_del($row->id, $this->route, ['edit' => ['status' => true],'delete' => ['status' => true]]);
                    return $html;
                })

                ->rawColumns(['position','action', 'item_type','custom_field_name'])
                ->make(true);
        }

        return view('admin.custom-fields.list', get_defined_vars());
    }

    public function add($type,$folder='')
    {
        $data = null;
        $main_t = job_type_slug($type);
        $items = job_type(true);
        $folders = $this->getFolders();
        $title = $this->titles['add'];
        if(!empty($folder)){
            $title = 'Add Custom Field Folder';
        }
        return view('admin.custom-fields.add', get_defined_vars());
    }

    public function getFolders(){
       return $this->model::where(company_user_fk(), login_id())->where('type','Folder')->get();
    }
    public function edit($id = null,$folder='')
    {

        $data = $this->model::findOrFail($id);
        $title =$data->custom_field_name;
        $folder = $data->type=="Folder"?"Folder":"";
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $folders = $this->getFolders();
        $main_t = job_type_slug($data->item_type);
        $items = job_type(true);
        return view('admin.custom-fields.edit', get_defined_vars());
    }

    public function save(Request $req, $id = null)
    {
        // dd($req->all());
        $this->validate($req,[
            'custom_field_name'=>'required',
        ]);
        $dt = [
            'custom_field_name' => $req->custom_field_name,
            'type' => $req->type,
            'item_type' => $req->item_type,
            
        ];
        if($req->type!="Folder"){
            $dt['parent_id'] = $req->parent_id??null;
        }
        if (is_null($id)) {
            $dt[company_user_fk()] = login_id();
            $this->model::create($dt);
            $msg = "Record Added Successfully!";
        } else {
            $fe = $this->model::findOrFail($id);
            if ($fe->{company_user_fk()} != login_id()) {
                return redirect()->back()->with('error', messages('not'));
            }
            $fe->update($dt);
            $msg = "Record Edited Successfully!";
        }
        if($req->has('save_add')){
            return  redirect()->route($this->route.'.list')->with('success', $msg);
         }
        return redirect()->back()->with('success', $msg);
    }

    public function delete($id = null)
    {
        $field = $this->model::findOrFail($id);
        if ($field->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $field->delete();
        return redirect()->back()->with('success', 'Record Delete Successfully!');
    }
    public function changeorder(Request $req)
    {
        $field = $this->model::findOrFail($req->id);
        if ($field->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $field->position=$req->position;
        $field->save();

        return redirect()->back()->with('success', 'Record Delete Successfully!');
    }

}
