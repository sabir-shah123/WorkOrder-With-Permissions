<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Item;
use App\Models\JobEstimate;
use App\Models\JobFields;
use App\Models\JobFile;
use App\Models\JobItem;
use Barryvdh\DomPDF\Facade\Pdf;
use Carbon\Carbon;
use DataTables;
use Illuminate\Http\Request;

class JobController extends Controller
{

    protected $route = 'job'; // route namespace
    protected $parent = 'Projects'; //on list this will be title
    protected $model = \App\Models\Job::class;
    protected $titles = ['add' => 'Add New Project', 'edit' => 'Edit Project'];
    public function __construct()
    {
        try {
            view()->share('route', $this->route);
            view()->share('parent', $this->parent);
        } catch (\Throwable$e) {
            # code...
        }
    }
    function list(Request $req, $type = '', $contactid = '') {
        $main_t = 'both';
        $prefix = 'create';

        if (!$req->has('item_type') && $type != '') {
            $main_t1 = job_type_slug($type);
            $req->item_type = $main_t1;
            $main_t = $type;
        }

        if (!$req->has('contactid') && $contactid != '') {
            $req->contactid = $contactid;
        }
        if ($req->ajax()) {
            $query = $this->model::where(company_user_fk(), login_id())->orderBy('created_at', 'DESC');

            return DataTables::eloquent($query)
                ->filter(function ($query) use ($req) {
                    if ($req->has('item_type') && $req->item_type != "both") {
                        $type = job_type_slug($req->item_type);
                        $query->where('job_type', $type);
                    }
                    if ($req->has('contactid') && $req->contactid != '') {
                        $query->where('contact_id', $req->contactid);
                    }
                    if ($req->has('pipeline_id') && $req->pipeline_id != '') {
                        $query->where('pipeline_id', $req->pipeline_id);
                    }
                    if ($req->has('status') && $req->status != '') {
                        $query->where('stage_id', $req->status);
                    }
                    if ($req->has('tags') && $req->tags != '') {
                        if (is_array($req->tags)) {
                            $tags = $req->tags;
                            $query->where(function ($query) use ($tags) {
                                foreach ($tags as $tag) {
                                    $query->orWhere('tags', 'like', '%' . $tag . '%');
                                }

                            });

                        }

                    }
                    if ($req->has('date_range')) {
                        $date_range = explode(" - ", $req->get('date_range'));
                        $query->whereBetween('created_at', [$date_range[0], $date_range[1]]);
                    }
                })
                ->addIndexColumn()
                ->editColumn('id', function ($row) {
                    return $row->id;
                })
                ->editColumn('due_date', function ($row) {
                    return getFormatDate($row->due_date, $row->due_time);
                })
                ->editColumn('created_at', function ($row) {
                    return getFormatDate($row->created_at);
                })
                ->editColumn('end_date', function ($row) {
                    return getFormatDate($row->end_date, $row->end_time);
                })

                ->editColumn('job_type', function ($row) {
                    return jobs_list()[$row->job_type];
                })
                ->addColumn('action', function ($row) {
                    $html = getAction();
                    $html .= dropdown_item($row->id, $this->route, 'estimates', 'Estimates');
                    $html .= dropdown_item($row->id, $this->route, 'images', 'Files');
                    $html .= dropdown_item($row->id, $this->route, 'view', 'View');
                    //$html .= change_status($row->id, $row->is_active, $this->route);
                    $html .= show_edit_del($row->id, $this->route, ['edit' => ['status' => true], 'delete' => ['status' => true]]);
                    return $html;
                })

                ->rawColumns(['action', 'status', 'job_type'])
                ->make(true);
        }
        $pipelines = get_pipelines();
        return view('admin.job.list', get_defined_vars());
    }
    public function estimates(Request $req, $id)
    {

        $data = $this->model::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $title = 'Estimates - ' . $data->job_title;

        if ($req->ajax()) {
            $query = $data->estimates()->orderBy('created_at', 'DESC');

            return DataTables::eloquent($query)
                ->filter(function ($query) use ($req) {

                })
                ->addIndexColumn()
                ->editColumn('id', function ($row) {
                    return $row->id;
                })
                ->addColumn('total', function ($row) {
                    $total = 0;
                    $material_cost = 0;
                    $sub_total = 0;
                    foreach ($row->items as $id => $it) {
                        $material_cost += $it->qty * $it->unit_cost;
                        $sub_total += $it->qty * $it->price;
                    }

                    return $material_cost + $sub_total;
                })
                ->editColumn('created_at', function ($row) {
                    return getFormatDate($row->created_at);
                })
                ->editColumn('estimate_date', function ($row) {
                    return getFormatDate($row->estimate_date);
                })
                ->editColumn('estimate_due', function ($row) {
                    return getFormatDate($row->estimate_due);
                })
                ->editColumn('status', function ($row) {
                    return ucwords($row->status);
                })
                ->addColumn('action', function ($row) {
                    $html = getAction();
                    $html .= dropdown_item($row->job_id . '/' . $row->id, $this->route, 'view', 'View');
                    $html .= dropdown_item([$row->job_id, 0, $row->id], $this->route, 'sendemail', 'Send email with Cost');
                    $html .= dropdown_item([$row->job_id, 1, $row->id], $this->route, 'sendemail', 'Send email without cost');
                    $html .= dropdown_item([$row->job_id, 0, $row->id, 1], $this->route, 'sendemail', 'Download PDF with Cost');
                    $html .= dropdown_item([$row->job_id, 1, $row->id, 1], $this->route, 'sendemail', 'Download PDF without cost');
                    $html .= dropdown_item($row->job_id . '/' . $row->id, $this->route, 'lineitems', 'Edit');
                    $html .= dropdown_item($row->job_id . '/' . $row->id, $this->route, 'deletelineitems', 'Delete', true);
                  
                    return $html;
                })

                ->rawColumns(['action'])
                ->make(true);
        }

        return view('admin.job.estimates', get_defined_vars());
    }

    public function create($type = 'job')
    {
        $main_t = job_type_slug($type);
        $type = $main_t;
        $title = 'Create New Work Order or Job';
        return view('admin.job.create', get_defined_vars());
    }

    public function get_job($type)
    {
        try {
            $job = jobs_list()[$type];
        } catch (\Throwable$e) {
            $job = jobs_list()[0];
        }
        return $job;
    }

    public function add($type, $contactid)
    {

        if (is_null($type) || is_null($contactid)) {
            exit;
        }
        $main_t = job_type_slug($type);
        $type = $main_t;
        $title = 'Create ' . $this->get_job($type);
        add_session('job_type', $type);
        $main_pipeline = get_custom_settings('pipeline_' . $type);
        $main_calendar = get_custom_settings('calendar_' . $type);
        add_session('contact_id', $contactid);
        $data = null;
        $fields = get_custom_fields_loc($type);
        $folders = get_custom_fields_loc_folders($type);
        $pipelines = get_pipelines();
        $calendars = get_calendars();
        $users = get_users();
        $tags = get_tags();
        $contact = get_contact($contactid);
        if (!$contact) {
            abort(404);
        }
        return view(admin_prefix() . $this->route . '.add', get_defined_vars());
    }

    public function free_slots(Request $request, $calendar)
    {
        $date = Carbon::parse($request->date);
        $start_date = $date->startOfMonth()->timestamp . '000';
        $end_date = $date->endOfMonth()->timestamp . '999';
        $allslots = ghl_api_call('appointments/slots?calendarId=' . $calendar . '&startDate=' . $start_date . '&endDate=' . $end_date);
        return response()->json($allslots);
    }

    public function view($id = null, $estimate_id = null)
    {
        $data = $this->model::with('fields', 'fields.customField')->findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $title = $data->job_title . ' - ' . jobs_list()[$data->job_type];
        $pipelines = get_pipelines();
        $main_pipeline = get_custom_settings('pipeline_' . $data->job_type);
        $main_calendar = get_custom_settings('calendar_' . $data->job_type);
        $users = get_users();
        // $job_fields = $data->fields()->where('item_type');
        $pdf = false;
        $fields = get_custom_fields_loc($data->job_type);
        $folders = get_custom_fields_loc_folders($data->job_type);
        $job_fields = $data->fields()->pluck('value', 'custom_id')->toArray();
        $calendars = get_calendars();
        $contact = get_contact($data->contact_id);
        if (!$contact) {
            abort(404);
        }
        $company = $data->company;
        $type = 0;
        add_session('ghl_api_key', $company->ghl_api_key);
        $location = get_location($company->location);
        session()->forget('ghl_api_key');
        return view(admin_prefix() . $this->route . '.view', get_defined_vars());
    }

    public function sendemail($id = null, $type = 1, $estimate_id = null, $pdf = null)
    {
        $data = $this->model::with('fields', 'fields.customField')->findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        if (!$estimate_id) {
            $estimate_id = '';
        } else {
            $estimate_id = '_' . $estimate_id;
        }
        $id = encrypt($id . '_' . $type . $estimate_id);
        if ($pdf) {
            return $this->projectview($id, true);
        } else {
            $link = route('projectview', $id);
            $replace = [];
            $replace['estimate_link'] = $link;
            $replace['project_title'] = $data->job_title;
            $replace['start_date'] = $data->due_date;
            $fields = setCustomFields($replace);
            $tag = $type == 0 ? 'tag_cost' : 'tag_no_cost';
            add_tags($data->contact_id, get_default_tag($tag), $fields);
            return redirect()->back()->with('success', 'Estimate View link with tag added to contact');
        }
    }

    public function projectview($id = null, $pdf = null)
    {
        $encid = $id;
        try {
            $id = decrypt($id);
        } catch (\Exception$e) {
            abort(404);
        }
        $type = explode('_', $id);
        $id = $type[0];
        $estimate_id = null;
        if (count($type) > 2) {
            $estimate_id = $type[2];
        }
        $type = $type[1];
        $data = $this->model::with('fields', 'fields.customField')->findOrFail($id);
        $company = $data->company;
        add_session('ghl_api_key', $company->ghl_api_key);
        $location = get_location($company->location);
        session()->forget('ghl_api_key');
        $title = $data->job_title . ' - ' . jobs_list()[$data->job_type];
        $pipelines = get_pipelines();
        $main_pipeline = get_setting($data->company->id, 'pipeline_' . $data->job_type);
        $main_calendar = get_setting($data->company->id, 'calendar_' . $data->job_type);
        $users = get_users();
        $job_fields = $data->fields()->pluck('value', 'custom_id')->toArray();
        $fields = get_custom_fields_loc($data->job_type);
        $folders = get_custom_fields_loc_folders($data->job_type);
        $calendars = get_calendars();
        $contact = get_contact($data->contact_id);
        if (!$contact) {
            abort(404);
        }
        $route = admin_prefix() . $this->route . '.publicview';
        // return view($route, get_defined_vars());
        if ($pdf) {
            try {
                @ini_set('max_execution_time', 0);
                @set_time_limit(0);
                $pdf = Pdf::loadView($route, get_defined_vars());
                $pdf->setWarnings(false);
                return $pdf->download('projectestimate.pdf');
            } catch (\Throwable$e) {
                abort(404);
            }
        }
        return view($route, get_defined_vars());
    }

    public function edit($id = null)
    {
        $data = $this->model::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $title = 'Edit ' . $this->get_job($data->job_type) . ' - ' . $data->job_title;
        $pipelines = get_pipelines();
        $main_pipeline = get_custom_settings('pipeline_' . $data->job_type);
        $main_calendar = get_custom_settings('calendar_' . $data->job_type);
        $users = get_users();
        $tags = get_tags();
        $fields = get_custom_fields_loc($data->job_type);
        $folders = get_custom_fields_loc_folders($data->job_type);
        $job_fields = $data->fields()->pluck('value', 'custom_id')->toArray(); //($data->job_type)->get();
        $calendars = get_calendars();
        $contact = get_contact($data->contact_id);
        if (!$contact) {
            abort(404);
        }
        return view(admin_prefix() . $this->route . '.edit', get_defined_vars());
    }
    public function files($id = null)
    {
        $data = $this->model::with('photos')->findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $title = $data->job_title . ' ' . $this->get_job($data->job_type) . ' Files';
        $contact = get_contact($data->contact_id);
        if (!$contact) {
            abort(404);
        }
        $subchild = getName($contact) . ' - ' . $this->get_job($data->job_type);
        $photos = $data->photos()->paginate(20);
        return view(admin_prefix() . $this->route . '.images', get_defined_vars());
    }
    public function deleteestimateitems($id = null, $estimate_id = null)
    {

        $data = $this->model::with('estimates')->findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        try {
            $data->estimates->find($estimate_id)->delete();
        } catch (\Exception$e) {
            return redirect()->back()->with('error', messages('not'));
        }

        return redirect()->back()->with('success', 'Record Delete Successfully!');
    }

    public function estimateitems($id = null, $estimate_id = null)
    {
        $data = $this->model::with('items', 'estimates')->findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        // \DB::statement("SET SQL_MODE=''");
        $title = 'Estimate - ' . $data->job_title . ' ' . $this->get_job($data->job_type);
        $contact = get_contact($data->contact_id);
        if (!$contact) {
            abort(404);
        }
        $subchild = getName($contact) . ' ' . $this->get_job($data->job_type);
        $estimate = $data->estimates()->find($estimate_id) ?? new JobEstimate();
        $items = $data->items()->where('estimate_id', $estimate_id)->with('item')->get();
        $lineitems = Item::where(company_user_fk(), login_id())->orderBy('item_title')->get();
        $main_items = [];

        $item_added = [];
        foreach ($lineitems as $lk) {
            $t = $lk->item_type;
            if (!isset($main_items[$t])) {
                $main_items[$t] = [];
            }
            $main_items[$t][] = $lk;
        }
        foreach ($items as $k) {
            $t = $k->item_type;
            if (!isset($item_added[$t])) {
                $item_added[$t] = [];
            }
            $item_added[$t][] = $k;
        }
        return view(admin_prefix() . $this->route . '.item', get_defined_vars());
    }

    public function saveestimateitems(Request $request, $id = null, $estimate_id = null)
    {
        $request->validate([
            'items' => 'required',
        ]);
        $data = $this->model::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $item_key = 'id';
        $job_key = 'estimate_id';
        $estimate = $data->estimates()->find($estimate_id) ?? new JobEstimate();
        $estimate->title = $request->estimate_title;
        $estimate->estimate_date = $request->estimate_date;
        $estimate->estimate_due = $request->estimate_due;
        $estimate->status = $request->status;
        $estimate->title = $request->estimate_title;
        $estimate->job_id = $id;
        $estimate->save();
        $already_ids = JobItem::where($job_key, $estimate_id)->get()->pluck($item_key)->toArray();
        $deleted = [];
        $itemids = [];
        try {

            $itemids = array_merge(array_values($request->items[0]['id']), array_values($request->items[1]['id']));
        } catch (\Exception$e) {

        }

        $deleted = array_diff($already_ids, $itemids);
        foreach ($deleted as $del) {
            $obj = JobItem::where($job_key, $estimate_id)->where('id', $del)->first();
            if ($obj) {
                $obj->delete();
            }
        }
        // dd($itemids);
        foreach ($request->items ?? [] as $id1 => $items) {
            try {
                $titles = $items['title'];
                $counts = count($titles);

                for ($i = 1; $i < $counts; $i++) {

                    try {

                        $item_id = $items['item_id'][$i];
                        $idest = $items['id'][$i];

                        $obj = JobItem::where($job_key, $estimate_id)->where('id', $idest)->first();
                        if (!$obj || is_null($idest)) {
                            $obj = new JobItem();
                        }
                        $obj->{$job_key} = $estimate_id;
                        $obj->job_id = $id;
                        $obj->item_id = $item_id;
                        $obj->item_type = $id1;
                        $obj->price = $items['price'][$i];
                        $obj->unit_cost = $items['unit_cost'][$i];
                        $obj->item_title = $items['title'][$i];
                        $obj->item_description = $items['description'][$i];
                        $obj->qty = $items['qty'][$i];
                        $obj->save();
                    } catch (\Exception$t) {
                        return response()->json(['message' => $t->getMessage(), 'status' => 200]);

                    }
                }
            } catch (\Throwable$e) {
                return response()->json(['message' => $e->getMessage(), 'status' => 200]);
            }

        }

        return response()->json(['message' => 'Saved', 'status' => 200]);
    }

    public function savefiles(Request $request, $id = null)
    {
        $request->validate([
            'images' => 'required',

        ]);
        $data = $this->model::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        foreach ($request->images as $fk) {
            $f = new JobFile();
            $f->job_id = $id;
            $f->name = $fk->getClientOriginalName();
            $f->url = uploadFile($fk, 'upload/jobfiles', 'job-' . $id . rand(1, 100000) . '-' . time());
            $f->save();
        }

        return redirect()->back()->with('success', 'Done');
    }

    public function save(Request $req, $id = null)
    {

        if (request()->has('choosename')) {
            $req->validate([
                'job_type' => 'required',
                'customer_id' => 'required',
            ]);

            if ($req->job_type == 1) {
                $req->job_type = 'job';
            } else {
                $req->job_type = 'workorder';
            }
            $url = route($this->route . '.add', ['type' => $req->job_type, 'contactid' => $req->customer_id]);
            return redirect($url);
        }

        $req->validate([
            'job_title' => 'required',
            'status' => 'required',
            //    'job_description' => 'required',
            //   'start_date' => 'required',
            // 'start_time' => 'required',

        ]);

        if (is_null($id)) {
            $cat = new $this->model();
            $cat->{company_user_fk()} = login_id();
            $cat->job_type = get_session('job_type');
            $cat->contact_id = get_session('contact_id');
            $cat->opportunity_id = '';
            $msg = "Record Added Successfully!";
        } else {
            $cat = $this->model::findOrFail($id);
            if ($cat->{company_user_fk()} != login_id()) {
                return redirect()->back()->with('error', messages('not'));
            }
            $msg = "Record Edited Successfully!";
            if ($cat->pipeline_id != $req->pipeline_id) {
                if ($cat->opportunity_id != "") {
                    $opportunity = ghl_api_call('pipelines/' . $cat->pipeline_id . '/opportunities/' . $cat->opportunity_id, 'DEL', '', [], true);

                }
                $cat->opportunity_id = '';
            }
        }
        $cat->job_title = $req->job_title;

        $cat->assigned_to = $req->assigned_to;

        $cat = set_value($cat, $req, 'assigned_to_name');
        $cat = set_value($cat, $req, 'pipeline_name');
        $cat = set_value($cat, $req, 'stage_name');
        $contact = get_session('ghl_contact_resp', null);
        $cat->contact_name = getName($contact);
        //$cat->calendar_name = $req->stage_name;

        $cat->pipeline_id = $req->pipeline_id;
        $cat->stage_id = $req->status;
        $cat->appointment_set = $req->has('appointment_set') ? 1 : 0;
        $cat->due_date = $req->start_date;
        $cat->end_date = $req->end_date;
        $cat->end_time = $req->end_time;
        $cat->due_time = $req->start_time;

        $cat->job_description = $req->job_description;
        $tags = new \stdClass;
        $tags->tags = $req->tags;
        $cat->tags = json_encode($tags);
        $cat->save();
        $data = new \stdClass;
        $data->stageId = $req->status;
        $data->contactId = $cat->contact_id;
        $data->assignedTo = $cat->assigned_to;

        //$data->name = $req->job_title;
        $data->title = $req->job_title . ' - ' . $this->get_job($cat->job_type);
        // $data->tags = $req->tags;
        $jobfield = JobFields::class;
        $job_key = 'job_id';
        $item_key = 'custom_id';
        $job_id = $cat->id;
        foreach ($req->fields ?? [] as $key => $value) {
            $obj = $jobfield::where($job_key, $id)->where($item_key, $key)->first();
            if (!$obj) {
                $obj = new $jobfield();
                $obj->job_id = $job_id;
                $obj->custom_id = $key;
            }

            $obj->value = $value;
            $obj->save();
        }

        if (is_null($id) || $cat->opportunity_id == "") {
            $data->status = 'open';
            $locId = auth()->user()->location;
            $location = get_location($locId);

            if ($location && !$location->settings->allowDuplicateOpportunity) {
                $loc = new \stdClass;
                $loc->businessName = $location->name;
                $loc->settings = $location->settings;
                $loc->settings->allowDuplicateOpportunity = true;

                $loc = ghl_api_call('locations/' . $locId, 'PUT', json_encode($loc), [], true);
            }

            $opportunity = ghl_api_call('pipelines/' . $req->pipeline_id . '/opportunities/', 'POST', json_encode($data), [], true);
            if ($opportunity && property_exists($opportunity, 'id')) {
                $cat->opportunity_id = $opportunity->id;
                $cat->save();
            }
        } else {
            $opportunity = ghl_api_call('pipelines/' . $req->pipeline_id . '/opportunities/' . $cat->opportunity_id, 'PUT', json_encode($data), [], true);
        }

        $error = false;
        if ($req->has('appointment_set')) {
            // $cat->appointment_set=1;
            $data = new \stdClass;
            if ($contact) {
                $type = 'phone';
                $value = '';
                if (property_exists($contact, 'phone')) {
                    $value = $contact->phone;
                } else {
                    $type = 'email';
                    $value = $contact->email;
                }
                if (!empty($value)) {
                    $data->{$type} = $value;
                    if (!is_null($cat->appointment_id) || !empty($cat->appointment_id)) {
                        ghl_api_call('appointments/' . $cat->appointment_id, 'DEL');
                        // $cat->appointment_id="";
                        // $cat->save();
                    }
                    $data->calendarId = $req->calendar_id;
                    $req1 = new \stdClass;
                    $req1->calendar_id = $req->calendar_id;
                    $timezoneoffset = ':00' . getUTCOffset($req->timezone);

                    $data->selectedTimezone = $req->timezone;
                    $req1->timezone = $req->timezone;
                    if ($req->has('appoint_type') || (!empty($req->appoint_start_time) && !empty($req->appoint_end_time))) {
                        $req1->appoint_type = $req->appoint_type;
                        $req1->appoint_start_time = $req->appoint_start_time;
                        $req1->appoint_end_time = $req->appoint_end_time;

                        $data->selectedSlot = $req->appoint_start_time . $timezoneoffset;
                        $data->endAt = $req->appoint_end_time . $timezoneoffset;
                    } else {
                        $data->selectedSlot = $req->appointment_time;
                        $req1->appointment_time = $req->appointment_time;
                    }
                    $cat->appointment_detail = json_encode($req1);
                    $appointment = ghl_api_call('appointments/', 'POST', json_encode($data), [], true);
                    if ($appointment && property_exists($appointment, 'id')) {
                        $cat->appointment_id = $appointment->id;
                    } else {
                        $msg = json_encode($appointment);
                        $error = true;
                    }
                    $cat->save();

                }

            }

        }

        $data = redirect()->route($this->route . '.lineitems', $cat->id);
        if (!is_null($id)) {
            $data = redirect()->back();
        }
        $type = 'success';
        if ($error) {
            $type = 'error';
        }
        if ($error && is_null($id)) {
            $data = redirect()->route($this->route . '.edit', $cat->id);
        }
        if ($req->has('save_add')) {
            return redirect()->route($this->route . '.list')->with($type, $msg);
        }
        return $data->with($type, $msg);
    }

    public function stage($id = null, $stage_id = null, $name = '')
    {
        $data = $this->model::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }

        $data1 = new \stdClass;
        $data1->stageId = $stage_id;
        $opportunity = ghl_api_call('pipelines/' . $data->pipeline_id . '/opportunities/' . $data->opportunity_id, 'PUT', json_encode($data), [], true);
        $data->stage_id = $stage_id;
        $data->stage_name = $name;
        $data->save();
        return redirect()->back()->with('success', 'Status Changed Successfully!');
    }
    public function stagewebhook(Request $req)
    {
        try {
            $location = $req->location['id'];
            $user = \App\Models\User::where('location', $location)->first();
            $job = $this->model::where('opportunity_id', $req->id)->first();
            if ($user && $job) {
                add_session('ghl_api_key', $user->ghl_api_key);

                $opportunity = ghl_api_call('pipelines/' . $req->pipeline_id . '/opportunities/' . $req->id);
                if ($opportunity && property_exists($opportunity, 'id')) {
                    $job->stage_id = $opportunity->pipelineStageId;
                    $job->stage_name = $req->pipleline_stage;
                    $job->pipeline_name = $req->pipeline_name;
                    $job->pipeline_id = $req->pipeline_id;
                    $job->save();
                }

            }
        } catch (\Exception$e) {

        }

    }

    public function delete($id = null)
    {
        $data = $this->model::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        if ($data->opportunity_id != "") {
            $opportunity = ghl_api_call('pipelines/' . $data->pipeline_id . '/opportunities/' . $data->opportunity_id, 'DEL', '', [], true);

        }
        if (!is_null($data->appointment_id) || !empty($data->appointment_id)) {
            ghl_api_call('appointments/' . $data->appointment_id, 'DEL');

        }

        $data->delete();
        return redirect()->back()->with('success', 'Record Delete Successfully!');
    }

    public function delete_files($id = null, $imgid = '')
    {

        $data = $this->model::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        try {
            if ($imgid == 'all') {
                $data->photos()->delete();
            } else {
                $data->photos->find($imgid)->delete();
            }
        } catch (\Exception$e) {
            return redirect()->back()->with('error', messages('not'));
        }

        return redirect()->back()->with('success', 'Record Delete Successfully!');
    }

    public function status($id)
    {
        $data = $this->model::findOrFail($id);
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $data->is_active = $data->is_active == 1 ? 0 : 1;
        $data->save();
        return back()->with('success', 'Status Changed Successfully.');
    }
}
