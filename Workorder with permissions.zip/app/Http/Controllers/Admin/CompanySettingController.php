<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

use App\Models\CompanySetting;
use Illuminate\Http\Request;

class CompanySettingController extends Controller
{
    protected $route = 'companysetting'; // route namespace
    protected $parent = 'Company Settings'; //on list this will be title
    protected $model = \App\Models\CompanySetting::class;
    public function __construct()
    {
        try {
            view()->share('route', $this->route);
            view()->share('parent', $this->parent);
        } catch (\Throwable$e) {
            # code...
        }
    }
    public function list()
    {
        $title = $this->parent;
        $company_settings = $this->model::where(company_user_fk(), login_id())->get()->pluck('value','key')->toArray();
//  'attachment' => 'nullable|mimes:jpeg,png,jpg,doc,pdf,docx,zip',
        $pipelines = get_pipelines();
        return view(admin_prefix() . $this->route . '.form', get_defined_vars());
    }


    public function store(Request $request)
    {
        foreach($request->settings as $key=>$value){
            save_custom_setting($key,$value);
        }
        return redirect()->back()->with('success','Saved');
    }

}
