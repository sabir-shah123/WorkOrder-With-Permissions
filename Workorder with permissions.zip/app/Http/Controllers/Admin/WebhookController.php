<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Job;
use App\Models\User;
use Illuminate\Http\Request;

class WebhookController extends Controller
{
    //
    protected $route = 'webhooks'; // route namespace
    protected $parent = 'Webhooks'; //on list this will be title
    public function __construct()
    {
        view()->share('route', $this->route);
        view()->share('parent', $this->parent);
    }
    function list() {
        return view(admin_prefix() . 'companysetting.webhook');
    }

    public function webhooks(Request $request, $type, $action)
    {

        if ($type == 'project') {
            echo $this->saveProject($request, $action);
        }
        if ($type == 'user' && $action == 'account') {
            echo $this->saveGhlContact($request);
        }
    }

    public function saveProjectCalendar($request, $action)
    {

    }

    public function saveProject($request, $action)
    {
        $action = job_type_slug($action);
        $customData = $request->customData;
        try {
            $location = $request->location['id'];
            $user = \App\Models\User::where('location', $location)->first();
            $job = \App\Models\Job::where('opportunity_id', $request->id)->first();
            $calendar=null;
            $startDate ='';
            $startTime ='';
            $endDate ='';
            $endTime ='';
            if($request->has('calendar'))    {
                $calendar = $request->calendar;
                $start = explode('T',$calendar['startTime']);
                $startDate = $start[0];
                $startTime = $start[1];
                $end = explode('T',$calendar['endTime']);
                $endDate = $end[0];
                $endTime = $end[1];
            }        
            if ($user) {
                add_session('ghl_api_key', $user->ghl_api_key);
                $pipeline_id = null;
                if (in_array('pipeline_id', array_keys($customData))) {
                    $pipeline_id = $customData['pipeline_id'];
                    $pipelines = get_pipelines();
                    $pipeline=null;
                    foreach ($pipelines as $pip) {
                        if ($pip->name == $pipeline_id) {
                            $pipeline_id = $pip->id;
                            $pipeline  =$pip;
                            break;
                        }
                    }
                }
                if($pipeline_id){
                    $opportunity = ghl_api_call('pipelines/' . $pipeline_id . '/opportunities?query=' . $request->email??$request->phone);
                    if($opportunity){
                        if(is_array($opportunity->opportunities) && count($opportunity->opportunities)>0){
                            $opportunity = $opportunity->opportunities[0];
                            if($opportunity->status!='open'){
                                $opportunity=null;
                            }
                            
                        }else{
                             return 'Opportunity not found';
                        }
                    }else{
                        return 'Not found or api key not working';
                    }
                   
                    
                }else{
                    $opportunity = ghl_api_call('pipelines/' . $request->pipeline_id . '/opportunities/' . $request->id);
                }
                
                if ($opportunity && property_exists($opportunity, 'id') && !$job) {
                    $pipelines = get_users();
                    $assiged_name='';
                    $opassigedid = $opportunity->assignedTo??'';
                    if(!empty($opassigedid)){
                        foreach ($pipelines as $pip) {
                        if ($pip->id == $opassigedid) {
                            $assiged_name= $pip->name;
                            break;
                        }
                       }
                    }
                    
                    $job = new Job();
                    $job->opportunity_id = $opportunity->id;
                    $job->stage_id = $opportunity->pipelineStageId;
                    if(is_object($pipeline)){
                        $stagename = '';
                        foreach($pipeline->stages as $stage){
                            if($stage->id==$opportunity->pipelineStageId){
                                $stagename =$stage->name;
                                break;
                            }
                        }
                    }
                    $job->stage_name = $request->stage_name??$stagename;
                    $job->pipeline_name = $customData['pipeline_id'];
                    $job->pipeline_id = $pipeline_id;
                    $job->appointment_set = 0;

                    $job->due_date = $customData->start_date ?? $startDate??null;
                    $job->end_date = $customData->end_date ?? $endDate??null;
                    $job->end_time = $customData->end_time ?? $endTime??null;
                    $job->due_time = $customData->start_time ?? $startTime??null;
                    $job->job_title = $customData->project_title ?? $opportunity->name;
                    $job->assigned_to = $opassigedid;
                    $job->assigned_to_name = $assiged_name;
                    $job->job_type = $action;
                    $job->{company_user_fk()} = $user->id; 
                    $job->contact_id = $opportunity->contact->id;
                    $job->contact_name = $opportunity->contact->name ?? '';
                    $job->job_description = $customData->job_description ?? '';
                    $job->appointment_id  =$calendar['appointmentId']??null;
                    $tags = new \stdClass;
                    $tags->tags = $customData['tags'] ?? '';

                    $tags->tags = explode(',', $tags->tags);
                    try {
                        $job->tags = json_encode($tags);
                    } catch (\Exception$e) {
                        //
                    }
                    $job->save();
                    return 'Job Created';
                }
                return 'Location not found';

            }
        } catch (\Exception$e) {
            return $e->getMessage();
        }
        return '';
    }
    /*

    "calendar":{"id":"K7W0EyUAfba09znyA0zD","title":"Saad Mukhtar","calendarName":"test","selectedTimezone":"Asia/Karachi","appointmentId":"chH8EWDWrmENmeaoLXng","startTime":"2022-10-04T01:00:00","endTime":"2022-10-04T01:30:00","status":"booked","appoinmentStatus":"confirmed","address":"","date_created":"2022-10-03T18:49:11.182Z","created_by":"","created_by_user_id":"","created_by_meta":{"source":"booking_widget","channel":"private_api"},"last_updated_by_meta":{"source":"booking_widget","channel":"private_api"}}

     */

    public function saveGhlContact(Request $request)
    {
        try {
            $loc = $request->location;
            $loc_data = $request->customData;
            if (!property_exists($request, 'email')) {
                return 'Email Required';
            }

            $pass = 'NextLevel#@' . rand(1, 100000);
            $company = User::where('email', $request->email)->first();
            if ($company) {
                return 'Email Already Exists';
            }

            $agency_key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb21wYW55X2lkIjoiOW1meWFkOWRiR1ZyemdCWDZnOHUiLCJ2ZXJzaW9uIjoxLCJpYXQiOjE2NjQ2NzA5NTA5MjYsInN1YiI6IkJBOTduaW5NMTN6OVpaUDE3eVI0In0.CFcJeZbiVwF56rF4aw0BeRRNgI5urjdOvZykeT5Ll_Q';
            add_session('ghl_api_key', $agency_key);
            $location = ghl_api_call('locations/lookup?email=' . $request->email);
            $usera = main_location();
            $request->pass = $pass;
            if (!$location || !property_exists($location, 'id')) {
                if ($usera) {
                    add_session('ghl_api_key', $usera->ghl_api_key);
                    sendDatatoghl($request, 'account_failed');
                }
                return 'Location not created yet inside agency';
            }
            $request->name = $request->full_name ?? $request->first_name . ' ' . $request->last_name;
            $new_user = User::create([
                'name' => $request->name,
                'email' => $request->email,
                'password' => bcrypt($pass),
                'role' => company_role(),
                'location' => $location->id,
                'ghl_api_key' => $location->apiKey,
            ]);

            if ($usera) {
                add_session('ghl_api_key', $usera->ghl_api_key);
                // event(new Registered($user));
                if ($new_user) {
                    sendDatatoghl($request, 'account_activated');
                    return 'Account Created ID : ' . $new_user->id;
                } else {
                    sendDatatoghl($request, 'account_failed');
                    return 'Unable to create account ';
                }

            }
        } catch (\Exception$e) {
            return $e->getMessage();
        }
        return 'Error';
    }
}
