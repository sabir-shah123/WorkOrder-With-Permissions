<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use DataTables;
use Illuminate\Http\Request;

class TagController extends Controller
{

    protected $route = 'tag'; // route namespace
    protected $parent = 'Tags'; //on list this will be title
    protected $model = \App\Models\Tag::class;
    protected $titles = ['add' => 'Add Tag', 'edit' => 'Edit Tag'];
    public function __construct()
    {
        view()->share('route', $this->route);
        view()->share('parent', $this->parent);
    }
    function list(Request $req, $type = '') {

        $show_all =true;
        $main_t = 'all';
        if (!$req->has('item_type') && $type != '') {
            $main_t1 = job_type_slug($type);
            $req->item_type = $main_t1;
            $main_t = $type;

        }

        if ($req->ajax()) {
            $query = $this->model::where(company_user_fk(), login_id())->orderBy('created_at', 'DESC');
            return DataTables::eloquent($query)
                ->filter(function ($query) use ($req) {
                    if ($req->has('item_type') && $req->item_type!='all') {

                        $type = job_type_slug($req->item_type);
                        $query->where('item_type', $type);
                    }
                })
                ->addIndexColumn()
                ->editColumn('id', function ($row) {
                    return $row->id;
                })
                ->editColumn('item_type', function ($row) {
                    return job_type(true)[$row->item_type];
                })

                ->addColumn('action', function ($row) {
                    $html = getAction();
                    $html .= show_edit_del($row->id, $this->route, ['edit' => ['status' => true],'delete' => ['status' => true]]);
                    return $html;
                })
                ->rawColumns(['action'])
                ->make(true);
        }

        return view(admin_prefix() . $this->route . '.list', get_defined_vars());
    }

    public function add($type)
    {
        $main_t = job_type_slug($type);
        $items = job_type(true);
        $title = $this->titles['add'];
        return view(admin_prefix() . $this->route . '.add', get_defined_vars());
    }

    public function edit($id = null)
    {


        $data = $this->model::findOrFail($id);
        $title =$data->title;
        if ($data->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $main_t = job_type_slug($data->item_type);
        $items = job_type(true);
        return view(admin_prefix() . $this->route . '.edit', get_defined_vars());
    }

    public function save(Request $req, $id = null)
    {
        $req->validate([
            'title' => 'required',
            'item_type' => 'required',
        ]);
        if (is_null($id)) {
            $obj = new $this->model();
            $obj->{company_user_fk()} = login_id();
            $msg = messages('add');
        } else {
            $obj = $this->model::findOrFail($id);
            if ($obj->{company_user_fk()} != login_id()) {
                return redirect()->back()->with('error', messages('not'));
            }
            $msg = messages('edit');
        }
        $obj->title = $req->title;
        $obj->item_type = $req->item_type;


        $obj->save();
        if($req->has('save_add')){
           return  redirect()->route($this->route.'.list')->with('success', $msg);
        }
        return redirect()->back()->with('success', $msg);
    }

    public function delete($id = null)
    {
        $st = $this->model::findOrFail($id);
        if ($st->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $st->delete();
        return redirect()->back()->with('success', messages('delete'));
    }

    public function status($id)
    {
        $st = $this->model::findOrFail($id);
        if ($st->{company_user_fk()} != login_id()) {
            return redirect()->back()->with('error', messages('not'));
        }
        $st->is_active = !$st->is_active;
        $st->save();
        return back()->with('success', messages('status'));
    }
}
