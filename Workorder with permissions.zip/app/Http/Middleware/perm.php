<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class perm
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request, Closure $next)
    {
        $user = auth()->user();
        if ($user->role != admin_role()) {

            
            $permissions = objToArray($user->permissions->permission ?? null);
            
            if (count($permissions) == 0) {
                $permissions =   objToArray(default_user_permissions());
                
            }
            
            $route = $request->route()->getName();
            $route = explode('.', $route);
            $route = $route[0];
            if($user->role==company_role() && $route == 'permission'){
                
            }elseif(session('super_admin')){
                
            }
            else{
                //$permissions = json_decode(json_encode($permissions), true);
             
                $is_perm = $permissions[$route] ?? false;
                $is_perm = $is_perm  ? true : false;
                if (!in_array($route, $permissions)  || !$is_perm) {
                    abort(403, 'You are not authorized to access this page');
                }
            }
            
        }
        return $next($request);
    }
}
