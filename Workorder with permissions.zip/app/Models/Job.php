<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Job extends Model
{
    use HasFactory;
    public function company()
    {
        return $this->belongsTo(User::class,'company_id');
    }
    public function photos(){
        return $this->hasMany(JobFile::class);
    }
    public function estimates(){
        return $this->hasMany(JobEstimate::class);
    }
    public function fields(){
        return $this->hasMany(JobFields::class);

        /*->where(function($query) use($type) {
            $query->where('item_type', $type)
            ->orWhere('item_type', 2);
        });*/
    }

   
    public function items(){
        return $this->hasMany(JobItem::class);
    }
}
