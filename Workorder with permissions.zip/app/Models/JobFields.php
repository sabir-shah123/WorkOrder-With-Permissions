<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobFields extends Model
{
    use HasFactory;
    public function customField(){
        return $this->belongsTo(CustomField::class,'custom_id');
    }
}
