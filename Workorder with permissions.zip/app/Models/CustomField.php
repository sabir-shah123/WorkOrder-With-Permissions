<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CustomField extends Model
{
    use HasFactory;
    protected $guarded =[];
    public $timestamps = false;
    public function fields(){
        return $this->hasMany(CustomField::class,'parent_id');
    }
    public function parent(){
        return $this->belongsTo(CustomField::class,'parent_id');
    }

}
