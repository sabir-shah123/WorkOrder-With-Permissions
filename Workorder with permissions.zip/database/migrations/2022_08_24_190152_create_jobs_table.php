<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateJobsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('jobs', function (Blueprint $table) {
            $table->id();
            $table->string('job_title');
            $table->string('pipeline_id');
            $table->text('job_description');
            $table->string('stage_id')->nullable(true);
            $table->integer('job_type');
            $table->dateTime('due_date');
            $table->dateTime('end_date');
            $table->foreignId('company_id')->constrained('users')->onDelete('cascade')->onUpdate('cascade');

            $table->integer('appointment_set')->default(0);
            $table->string('assigned_to');
            $table->string('contact_id');
            $table->boolean('is_active')->default(1);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('jobs');
    }
}
