<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddStatusandestimatedueandestimatedateToJobEstimates extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('job_estimates', function (Blueprint $table) {
            $table->date('estimate_date')->nullable();
            $table->date('estimate_due')->nullable();
            $table->string('status')->nullable()->default('draft');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('job_estimates', function (Blueprint $table) {
            //
        });
    }
}
